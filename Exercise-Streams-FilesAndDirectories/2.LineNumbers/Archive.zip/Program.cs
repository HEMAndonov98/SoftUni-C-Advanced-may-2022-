﻿namespace LineNumbers
{
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class LineNumbers
    {
        static void Main()
        {
            string inputFilePath = @"../../../text.txt";
            string outputFilePath = @"../../../output.txt";

            ProcessLines(inputFilePath, outputFilePath);
        }

        public static void ProcessLines(string inputFilePath, string outputFilePath)
        {
            string[] lines = File.ReadAllLines(inputFilePath);
            List<string> modifiedLines = new List<string>();
            for (int i = 1; i <= lines.Length; i++)
            {
                string modified = $"Line {i}: {lines[i - 1]} ({lines[i - 1].Count(char.IsLetter)})({lines[i - 1].Count(char.IsPunctuation)})";
                modifiedLines.Add(modified);
            }
            File.WriteAllLines(outputFilePath, modifiedLines);
        }
    }
}
