﻿using System;
using System.Runtime.CompilerServices;

namespace Renovators
{
    public class StartUp
    {
        static void Main()
        {
        }
    }
}
