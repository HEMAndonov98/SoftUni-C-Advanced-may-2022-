﻿using System;

namespace BoxOfT
{
    class StartUp
    {
        static void Main(string[] args)
        {
            var box = new Box<int>();
            box.Add(1);
            box.Add(2);
            box.Add(3);
            box.Remove();
            Console.WriteLine(box.Count);
        }
    }
}

