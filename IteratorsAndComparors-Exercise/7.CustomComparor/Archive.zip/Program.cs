﻿using System;
using System.Linq;

namespace _7.CustomComparor
{
    class Program
    {
        static void Main(string[] args)
        {
            var numbers = Console.ReadLine()
                .Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();

            Array.Sort(numbers, new ArrayComparor());
            Console.WriteLine(String.Join(' ', numbers));
        }
    }
}

