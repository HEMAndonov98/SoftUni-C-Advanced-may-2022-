﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace _7.CustomComparor
{
	public class ArrayComparor : IComparer<int>
	{

        public int Compare([AllowNull] int x, [AllowNull] int y)
        {
            Func<int, int, int> sortEvenAndOdd = (x, y) =>
            {
                if (Math.Abs(x) % 2 == 0 && Math.Abs(y) % 2 != 0)
                {
                    return -1;
                }
                else if (Math.Abs(x) % 2 != 0 && Math.Abs(y) % 2 == 0)
                {
                    return 1;
                }
                else 
                {
                    return 0;
                }
            };
            return sortEvenAndOdd(x, y);
        }
    }
}

